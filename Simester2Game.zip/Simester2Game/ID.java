public enum ID {
    Player(),
    BasicEnemy(),
    YumYum(),
    HUD(),
    Trail();
}
